
package coe528.project;

public abstract class Tiers {

    public abstract void changeTier(Account a);
    
    abstract void onlinePurchase(Account a,int cost);
    

}
